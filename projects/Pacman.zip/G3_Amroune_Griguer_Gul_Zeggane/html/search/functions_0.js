var searchData=
[
  ['clearscreen_0',['ClearScreen',['../gridmanagement_8h.html#a6a3ca153f0817e8ba91a023b886bb662',1,'gridmanagement.cpp']]],
  ['color_1',['Color',['../gridmanagement_8h.html#a7f0df05a97c053bfa8a3e5863b0a0e80',1,'gridmanagement.h']]],
  ['configureterminal_2',['configureTerminal',['../main_8cpp.html#a99ef3a179f716f9f6c9b973250605550',1,'main.cpp']]]
];
